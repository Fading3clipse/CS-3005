#include "image_menu.h"

std::string getString(std::istream& is, std::ostream& os, const std::string& prompt) {
	std::string answer;
	os << prompt;
	is >> answer;
	return answer;
}

int getInteger(std::istream& is, std::ostream& os, const std::string& prompt) {
	int answer;
	os << prompt;
	is >> answer;
	return answer;
}
double getDouble(std::istream& is, std::ostream& os, const std::string& prompt) {
	double answer;
	os << prompt;
	is >> answer;
	return answer;
}
int assignment1(std::istream& is, std::ostream& os) {
	std::string color = getString(is, os, "What's your favorite color? ");
	int num = getInteger(is, os, "What's your favorite integer? ");
	double f = getDouble(is, os, "What's your favorite number? ");
	for(int i=0; i<num; i++) {
		os << i+1 << " " << color << " " << f << std::endl;
	}
	return num;
}
